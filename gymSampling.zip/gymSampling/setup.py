from setuptools import setup

setup(name='gymSampling',
      version='1.0',
      install_requires=['gym', 'gym_cartpole_swingup']
)